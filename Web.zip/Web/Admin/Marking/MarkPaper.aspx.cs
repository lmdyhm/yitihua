﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using BLL;
using Entity;

public partial class Admin_Test_MarkPaper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
        {
            if(Request.QueryString["recorderID"]!=null)
                hfdRecorderID.Value=Request.QueryString["recorderID"].ToString();
            if (Request.QueryString["testID"] != null)
                hfdTestID.Value = Request.QueryString["testID"].ToString();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        TextBox txtTesterMark = (TextBox)FormView1.FindControl("txtTesterMark");
        TextBox txtRemark = (TextBox)FormView1.FindControl("txtRemark");

        TestMark testMark = new TestMark();
        testMark.TotalScore = Convert.ToUInt16(txtTesterMark.Text);
        testMark.Remark = txtRemark.Text;
        testMark.Marker = SessionClass.GetLoginUser();
        testMark.MarkedTime = DateTime.Now;
        testMark.TestRecorder.RecorderID =Convert.ToInt32( hfdRecorderID.Value);

        new BLLTestMark().CreateTestMark(testMark);
        Response.Redirect("TesterList.aspx?testID="+hfdTestID.Value);
    }
}
