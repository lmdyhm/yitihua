﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Entity;
using BLL;

public partial class Admin_Paper_PaperDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
        {
            Paper paper = new BLLPaper().GetPaperByID(paperID);
            if (paper != null)
                BindPaperInfo(paper);

        }
    }

    private string paperID
    {
        get
        {
            return Request.QueryString["paperID"];
        }
    }

    private void BindPaperInfo(Paper paper)
    {
        lblPaperName.Text = paper.PaperName;
        SessionClass.SetPaperContent(paper.Content);
        txtPaperAnswer.Text = paper.Answer;
    }
}
