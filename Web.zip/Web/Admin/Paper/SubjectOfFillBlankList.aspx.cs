﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Text;

using Entity;
using BLL;

public partial class Admin_Paper_SubjectOfFillBlankList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
    }
    protected void ObjectDataSource1_Selected(object sender, ObjectDataSourceStatusEventArgs e)
    {
        List<SubjectOfFillBlank> list = (List<SubjectOfFillBlank>)e.ReturnValue;
        lblRecorderSum.Text = list.Count.ToString();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        List<int> idList = new List<int>();
        for (int i = 0; i < rptSubjectOfFillBlankList.Items.Count; i++)
        {
            CheckBox tb = (CheckBox)rptSubjectOfFillBlankList.Items[i].FindControl("CheckBox1");
            if (tb.Checked)
            {
                HiddenField hf = (HiddenField)rptSubjectOfFillBlankList.Items[i].FindControl("HiddenField1");
                idList.Add(Convert.ToInt32(hf.Value));
            }
        }

        if (idList.Count > 0)
        {
            List<SubjectOfFillBlank> list = new BLLSubjectOfFillBlank().GetSubjectList(idList);
            SessionClass.SetFillBlankList(list);
        }
        else
            SessionClass.SetFillBlankList(null);

        Response.Redirect("AddPaperByManualSelection.aspx");
    }

    protected void drpSubjectTypeCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        rptSubjectOfFillBlankList.DataBind();
    }
}
