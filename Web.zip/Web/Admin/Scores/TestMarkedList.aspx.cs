﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Entity;
using BLL;
using Tool;

public partial class Admin_Scores_TestMarkedList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
        {
            int pageNum = 1;
            if (Request.QueryString["pageNum"] != null)
                pageNum = Convert.ToInt32(Request.QueryString["pageNum"]);
            BindTestList(pageNum);
        }
    }

    private const int PAGE_SIZE = 20;
    private void BindTestList(int pageNum)
    {
        PageList<Test> list = new BLLTest().GetTestList(pageNum, PAGE_SIZE);
        rptTestList.DataSource = list.RecorderList;
        rptTestList.DataBind();
        lblPageUrl.Text = StringHelper.MakePageUrl("?pageNum=", pageNum, list.PageCount, list.RecorderCount);
    }

    protected void btnSearchScores_Click(object sender, EventArgs e)
    {
        if(rblSearchType.SelectedValue=="1")//姓名
            Response.Redirect("TesterMarkedList.aspx?name="+txtUserID.Text);
        else
            Response.Redirect("TesterMarkedList.aspx?userID=" + txtUserID.Text);
    }
}
