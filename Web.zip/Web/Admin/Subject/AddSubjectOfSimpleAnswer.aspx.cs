﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Entity;
using BLL;

public partial class Admin_Subject_AddSubjectOfSimpleAnswer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
        {
            txtQuestion.Focus();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SubjectOfSimpleAnswer subject = new SubjectOfSimpleAnswer();
        SubjectTypeCategory category = new SubjectTypeCategory();
        category.CateID = Convert.ToInt32(drpSubjectTypeCategory.SelectedValue);
        subject.Category = category;
        subject.Question = txtQuestion.Text;
        subject.Answer = txtAnswer.Text;

        new BLLSubjectOfSimpleAnswer().CreateSubject(subject);
        Response.Redirect("SubjectOfSimpleAnswerList.aspx");
    }
}
