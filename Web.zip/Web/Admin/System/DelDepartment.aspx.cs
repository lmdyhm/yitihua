﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Entity;
using BLL;

public partial class Admin_System_DelDepartment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
            DeleteDept();
    }

    private string deptID
    {
        get
        {
            return Request.QueryString["deptID"];
        }
    }

    private void DeleteDept()
    {
        try
        {
            new BLLDepartment().RemoveDept(deptID);
            Response.Redirect("departmentList.aspx");
        }
        catch
        {
            Response.Write("删除失败，很可能是存在该部门的试卷，请将该部门的试卷删除后再试！");
        }
    }
}
