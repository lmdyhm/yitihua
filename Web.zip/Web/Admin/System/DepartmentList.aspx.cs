﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_System_DepartmentList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
    }
    protected void objdsDepartmentList_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
    {
        
    }
    protected void objdsDepartmentList_Selected(object sender, ObjectDataSourceStatusEventArgs e)
    {
        List<Entity.Department> deptList = (List<Entity.Department>)e.ReturnValue;
        if (deptList != null)
            lblSum.Text = deptList.Count.ToString();
    }
}
