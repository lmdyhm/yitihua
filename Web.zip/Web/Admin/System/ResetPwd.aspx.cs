﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using BLL;

public partial class Admin_System_ResetPwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
            ResetPwd();
    }

    private string userID
    {
        get { return Request.QueryString["userID"]; }
    }

    private void ResetPwd()
    {
        try
        {
            BLLAdmin bll = new BLLAdmin();
            bll.ResetPwd(userID);
            Response.Write(string.Format("重置密码成功！{0}的新密码为: {1}",userID,BLLAdmin.DEFAULT_PWD ) );
        }
        catch
        {
            Response.Write("重置密码失败！");
        }
    }
}
