﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using BLL;

public partial class Admin_Test_DelTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DelTest();
    }

    private string testID
    {
        get
        {
            return Request.QueryString["testID"];
        }
    }

    private void DelTest()
    {
        int id = 0;
        if (int.TryParse(testID, out id))
        {
            try
            {
                new BLLTest().RemoveTest(id);
                Response.Redirect("testList.aspx");
            }
            catch
            {
                Response.Write("删除失败！");
            }
        }
    }


}
