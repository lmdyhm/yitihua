﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Entity;
using BLL;

public partial class Admin_Test_SetScores2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RoleCheck.DenyLogin();
        if (!IsPostBack)
            BindInfo();
    }
    private void BindInfo()
    {
        PaperByRandomSelection paper = new BLLPaperByRandomSelection().GetPaper2(paperID);
        if (paper != null)
        {
            SessionClass.SetPaperTilte(paper.PaperName);
            Label1.Text = paper.JudgeSum.ToString();
            Label2.Text = paper.SingleSelectionSum.ToString();
            Label3.Text = paper.MultiSelectionSum.ToString();
        }
    }

    private int paperID
    {
        get { return Helper.GetUrlParmValue("paperID"); }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SessionClass.SetJudgeScoresOfEveryone(Convert.ToInt32(TextBox1.Text));
        SessionClass.SetSingleSelectionScoresOfEveryone(Convert.ToInt32(TextBox2.Text));
        SessionClass.SetMultiSelectionScoresOfEveryone(Convert.ToInt32(TextBox3.Text));
        SessionClass.SetTotalScores(Convert.ToInt32(txtTotalScores.Text));

        Response.Redirect("addTest.aspx?paperType=2&paperID=" + paperID);
    }
}
