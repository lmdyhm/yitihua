﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for Helper
/// </summary>
public class Helper
{
    public Helper()
    {
    }

    public static int GetUrlParmValue(string parmName)
    {
        if (HttpContext.Current.Request.QueryString[parmName] == null)
            HttpContext.Current.Response.Redirect("~/error/error.aspx?msg=" + "参数" + parmName + "为空！");
        int parmValue = 0;
        try
        {
            parmValue = Convert.ToInt32(HttpContext.Current.Request.QueryString[parmName]);
        }
        catch
        {
            HttpContext.Current.Response.Redirect("~/error/error.aspx?msg=" + "参数" + parmName + "错误！");
        }
        return parmValue;
    }

    public static void Alert_Ajax(Control contr, string alertTitle)
    {
        string script = string.Format("alert('{0}')", alertTitle);
        ScriptManager.RegisterStartupScript(contr, contr.GetType(), "", script, true);
    }

    public static void ClosePage_Ajax(Control contr, string alertTitle)
    {
        string script = string.Format("alert('{0}'); window.opener=null; window.open('','_self','');  window.close();", alertTitle);

        ScriptManager.RegisterStartupScript(contr, contr.GetType(), "", script, true);
    }
}
