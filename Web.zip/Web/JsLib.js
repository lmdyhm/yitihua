﻿//版权所有：http://www.kabahu.com

//将焦点设置在文字后面
function getSelectPos(id){
    var esrc = document.getElementById(id);
    if(esrc==null){
       esrc=event.srcElement;
    }

    if(!esrc)
        return;
    try{
            var rtextRange =esrc.createTextRange();
            rtextRange.moveStart('character',esrc.value.length);
            rtextRange.collapse(true);
            document.getElementById(id).focus();
            rtextRange.select();
       }
    catch(error){
        document.getElementById(id).focus();
    }
}

var cookieDomain="ruimingde.com";//本地
//var cookieDomain="kabahu.com"; //服务器上的
//写cookies函数 作者：翟振凯(http://blog.csdn.net/zxmcl/archive/2007/08/02/1723595.aspx)
function setCookie(name,value,Days)//两个参数，一个是cookie的名子，一个是值
{
    if(getCookie(name)!=null)//已存在删除
        delCookie(name);
    var exp  = new Date();    //new Date("December 31, 9998");
    exp.setTime(exp.getTime() + Days*24*60*60*1000);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString()+";path=/"+ (cookieDomain ? (";domain="+cookieDomain) : "");
}


function setCookieOutDomain(name,value,Days)//跨域cookie（卡巴虎一键收藏用到）
{
    if(getCookie(name)!=null)//已存在删除
        delCookie(name);
    var exp  = new Date();    //new Date("December 31, 9998");
    exp.setTime(exp.getTime() + Days*24*60*60*1000);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}

function getCookie(name)//取cookies函数        
{
     var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
     if(arr != null) return unescape(arr[2]); return null; 

}

function getParentCookie(name)//取cookies函数        
{
     var arr = parent.document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
     if(arr != null) return unescape(arr[2]); return null; 

}
function delCookie(name)//删除cookie
{
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(name);
    if(cval!=null) document.cookie= name + "="+cval+";expires="+exp.toGMTString()+";path=/"+ (cookieDomain ? (";domain="+cookieDomain) : "");
}

//获取url上的参数
function QueryString(id)
{
    var svalue = location.search.match(new RegExp("[\?\&]" + id + "=([^\&]*)(\&?)", "i"));
        return svalue ? svalue[1] : "";
}

//ie6下实现posttion:fixed效果（不过存在闪烁）
function IE6_FixedTop(id, top)
{   
    var obj=document.getElementById(id);
    if(!obj)
        return;
    var ie6 = !window.XMLHttpRequest;
    obj.style.position = ie6 ? 'absolute' : 'fixed';

    if (ie6) {
            window.onscroll=function(){
            obj.style.top=(document.body.scrollTop||document.documentElement.scrollTop)+top+'px'; 
        } 
        window.onresize=function(){
            obj.style.top=(document.body.scrollTop||document.documentElement.scrollTop)+top+'px'; 
        }
    } 
}

//ie6下实现posttion:fixed效果（不过存在闪烁）
function IE6_FixedBottom(id,bottom)
{   
    var obj=document.getElementById(id);
    if(!obj)
        return;
    var ie6 = !window.XMLHttpRequest;
    obj.style.position = ie6 ? 'absolute' : 'fixed';
    if (ie6) {
   
            window.onscroll=function(){
            var initTop = (document.documentElement.clientHeight-obj.offsetHeight-bottom);
            obj.style.top= (document.body.scrollTop||document.documentElement.scrollTop) + initTop+"px";
        } 
        window.onresize=function(){
           var initTop = (document.documentElement.clientHeight-obj.offsetHeight-bottom);
           obj.style.top=(document.body.scrollTop||document.documentElement.scrollTop) + initTop+"px";
        }
    } 
}


//判断是否为整数
function IsInt(value)
{
    var exp=/^[0-9]+[0-9]*]*$/;
    return exp.test(value);
}

function IsEmail(value)
{
     var pattern = /^([a-zA-Z0-9._-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/; 
     var flag = pattern.test(value); 
     if(!flag)
        return false;
     else
        return true;
}
function IsUrl(value)
{
    var pattern = /[a-zA-z]+:\/\/[^s]*/i; 
    return pattern.test(value);     

}
function hideElement(eleId)
{
    var ele = document.getElementById(eleId);
    if(ele)
        ele.style.display='none';
}

function showElement(eleId)
{
    var ele = document.getElementById(eleId);
    if(ele)
        ele.style.display='';
}

//记录网址查看历史（标题优先使用title，如果title未定义使用name <a >name</a>
function recordHistory(objA)
{
        var url= objA.attributes.getNamedItem("href")==null ? "" : objA.attributes.getNamedItem("href").value;
        var title= objA.attributes.getNamedItem("title")==null ? "" : objA.attributes.getNamedItem("title").value;
        if(title=="")
            title= typeof(objA.innerText)=="undefined" ? objA.innerHTML : objA.innerText;//ie识别innerText、ff识别innerHTML
        title= getSubStr(title,20);//截取前20个字符
        var _cookieValue= url+"⊙"+title;

        var cookieKey="historyLink_"+getCookie("LastLoginSuccessName")
        var historyLink=getCookie(cookieKey);
        if(historyLink==null)
            setCookie(cookieKey,_cookieValue,30);
        else{
            var strLink=""+_cookieValue;//最新访问的放在cookie的最前面
            var maxLink=20;//最多保存20个网址
            var arrLink= historyLink.split('≌');
            for(var i=0; i<arrLink.length; i++){
                if(i>(maxLink-2))//超过最大限制
                    break;
                if(arrLink[i]!=_cookieValue)//去掉重复网址
                    strLink+= "≌" +arrLink[i];
            }
            setCookie(cookieKey,strLink,30);
        }

}
//获取网址查看历史的html
function getHistoryHtml()
{
     var cookieKey="historyLink_"+getCookie("LastLoginSuccessName");
     var historyLink=getCookie(cookieKey);
     if(historyLink==null)
        return "";
     else{
            var html="<ul>";
            var arrLink= historyLink.split('≌');
            var showMax=10;
            for(var i=0; i<arrLink.length && i<showMax; i++){
                var arrLinkItem=arrLink[i].split('⊙');
                var url= arrLinkItem[0];
                var title = arrLinkItem[1];
                html+='<li><a href="'+url+'" title="'+title+'" target="_blank">'+getSubStr(title,12)+'</a></li>';
            }
            html+="</ul>";
            return html;
     }
}
//清空查看历史
function clearHistory(divId)
{
    var cookieKey="historyLink_"+getCookie("LastLoginSuccessName");
    delCookie(cookieKey);
    var divObj= document.getElementById(divId);
    if(divObj)
        divObj.innerHTML=getHistoryHtml();
}

function getSubStr(str,len)
{
    if(str && str.length>0)
        return str.substr(0,(str.length>len ? len : str.length));
    else
        return "";
}

//ajax异常反馈
function submitError(req)
{
    if(!confirm("真抱歉！网站发生错误，您是否反馈？"))
        return;
    var submitDateCookie=getCookie("submitDateCookie");
    var cookieMins=1;//1分钟
    if(submitDateCookie==null)
        setCookie("submitDateCookie",1,cookieMins/(24*60));//该函数的cookie时间只支持天
    else{
        alert("您的反馈我们已经收到，"+cookieMins+"分钟内不能再反馈");
        return;
    }
        
    alert("感谢您的反馈:)");
    var errorText= req.responseText;
    $.post("/Handler/Error.ashx?action=submitError","errorText="+encodeURIComponent(errorText),function(data){});
    
}
//限制的文字长度,调用方式（需要加上2个事件）：onkeyup="limitInputLength(this,500,'spanSiteDespMax')" onblur="limitInputLength(this,500,'spanSiteDespMax')"//防止用鼠标进行黏贴的
function limitInputLength(objTxt,maxLength,spanCounterId)
{
    if(objTxt.value.length>maxLength)
        objTxt.value= objTxt.value.substr(0,maxLength);
    document.getElementById(spanCounterId).innerHTML=""+(maxLength-objTxt.value.length);
}

/*
参数说明：
1、未传入sURL的自动获取页面的地址
2、未传入sTitle的自动获取页面的标题
*/
function AddFavorite(sURL, sTitle)//加入收藏 from：http://www.cnblogs.com/moozi/archive/2008/04/16/1156339.html
{
    var _sURL="";
    var _sTitle="";
    if(typeof(sURL)=="undefined" || sURL==null || sURL=="")//未传入sURL的自动获取页面的地址
        _sURL = window.location;
    else
        _sURL= sURL;
        
    if(typeof(sTitle)=="undefined" || sTitle==null || sTitle=="")//未传入sTitle的自动获取页面的标题
        _sTitle = window.document.title;
    else
        _sTitle= sTitle;
    try
    {
        window.external.addFavorite(_sURL, _sTitle);
    }
    catch (e)
    {
        try
        {
            window.sidebar.addPanel(_sTitle, _sURL, "");
        }
        catch (e)
        {
            alert("加入收藏失败，请使用Ctrl+D进行添加");
        }
    }
}

/*
参数说明：未传入url的自动获取页面的地址
*/
function setHomepage(url)
{
      var _url="";
      if(typeof(url)=="undefined" || url==null || url=="")//未传入url的自动获取页面的地址
        _url = window.location;
      else
        _url= url;
    
    if (document.all)
    {
        document.body.style.behavior='url(#default#homepage)';
        document.body.setHomePage(_url);
    }
    else if (window.sidebar)
    {
        if(window.netscape)
         {
             try
            { 
                netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect"); 
            } 
            catch (e) 
             { 
                alert( "该操作被浏览器拒绝，如果想启用该功能，请在地址栏内输入 about:config,然后将项 signed.applets.codebase_principal_support 值该为true" ); 
            }
         }
        var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components. interfaces.nsIPrefBranch);
        prefs.setCharPref('browser.startup.homepage',_url);
   }
}

//使用jiathis分享网址
function getJiaThisShare(title,url)
{

    var script='<script type="text/javascript">';
    script+='var jiathis_config = {';
	script+='url: "'+encodeURIComponent(url)+'",';
	script+='title: "'+encodeURIComponent(title)+'"';
    script+='}</script>';
    script +='<script type="text/javascript" src="http://www.jiathis.com/code/jiathis_r.js?move=0" charset="utf-8"></script>';
    return script;

}

//按回车提交表单 调用方式：EnterKeyLogin(event,submtLogin)
function enterKeySubmit(eventTarget,fnCallBack)
{
    var evt =window.event||eventTarget;
    var keycode= evt.charCode || evt.keyCode;
    if(keycode==13)
    {
       fnCallBack.call();
    }

}
//iframe高度自适应
function autoIframeHeight(objIfrme,minHeight)
    {
       var newHeight;
       if (objIfrme.Document){
              newHeight = objIfrme.Document.body.scrollHeight;
       }else{
              newHeight = objIfrme.contentDocument.body.scrollHeight;
       }
       if(newHeight<minHeight)
           newHeight =minHeight;
       objIfrme.style.height = (newHeight+10)+"px";
    }


var sourceDomain ={};
sourceDomain.imgDomain="http://img.ruimingde.com";
sourceDomain.cssDomain="http://css.ruimingde.com";
sourceDomain.jsDomain="http://js.ruimingde.com";
 
