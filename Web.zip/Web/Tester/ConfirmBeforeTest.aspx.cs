﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

using Entity;

public partial class Tester_ConfirmBeforeTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("TestList.aspx");
    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        string url=string.Empty;
        int paperType=Helper.GetUrlParmValue("paperType");
        int recorderID = Helper.GetUrlParmValue("recorderID");
        int testID=Helper.GetUrlParmValue("testID");
        int paperID = Helper.GetUrlParmValue("paperID");

        switch ((PaperType)paperType)
        {
            case PaperType.BySelection:
            case PaperType.ByRandom:
                url = string.Format("doTest2.aspx?testID={0}&paperType={1}&recorderID={2}&paperID={3}", testID, paperType,recorderID, paperID);
                break;
            case PaperType.ByInput:
                url = string.Format("doTest.aspx?testID={0}", testID);
                break;
            default:
                break;
        }
        Tool.JscriptHelper.OpenNewPage(url,700,1000);
    }
}
