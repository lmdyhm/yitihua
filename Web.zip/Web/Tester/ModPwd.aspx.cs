﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using BLL;

public partial class Tester_ModPwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int returnVaule = 0;
        if (null != SessionClass.GetLoginUser())
        {
            returnVaule = new BLLUser().ModifyPwd(SessionClass.GetLoginUser().UserID, txtOldPwd.Text, txtNewPwd.Text);
        }

        switch (returnVaule)
        {
            case -1: { lblMsg.Text = "原密码错误！"; txtOldPwd.Focus(); break; }
            case 0: { lblMsg.Text = "修改失败！请重试！"; break; }
            case 1: { lblMsg.Text = "修改成功！"; break; }
        }
    }
}
